#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Additional charges (optional)
const float VAT_RATE = 0.15; // 15%
const float SERVICE_FEE_RATE = 0.05; // 5%
const float DISCOUNT_RATE = 0.10; // 10%

enum CustomerType {
    DOMESTIC,
    COMMERCIAL,
    MEDIUM_INDUSTRIAL,
    UNKNOWN
};

struct Customer {
    string name;
    CustomerType customerType;
    float consumption;
    float total_bill;
};

// Determining customer type from string
CustomerType determineCustomerType(const string& type) {
    if (type == "Domestic" || type == "D") return DOMESTIC;
    if (type == "Commercial" || type == "C") return COMMERCIAL;
    if (type == "Medium Industrial" || type == "M") return MEDIUM_INDUSTRIAL;
    return UNKNOWN;
}

// Function for determining total bill
float calculate_bill(const Customer& customer) {
    float bill = 0.0;
    switch (customer.customerType) {
        case DOMESTIC:
            if (customer.consumption <= 15) {
                bill = customer.consumption * 250.0;
            } else if (customer.consumption <= 80) {
                bill = customer.consumption * 797.3;
            } else if (customer.consumption <= 150) {
                bill = customer.consumption * 412.0;
            } else {
                bill = customer.consumption * 797.3;
            }
            break;
        case COMMERCIAL:
        case MEDIUM_INDUSTRIAL: {
            char timeOfUse;
            cout << "Enter time-of-use (P for Peak, S for Shoulder, O for Off-Peak): ";
            cin >> timeOfUse;
            if (customer.customerType == COMMERCIAL) {
                if (timeOfUse == 'P' || timeOfUse == 'p') {
                    bill = customer.consumption * 791.9;
                } else if (timeOfUse == 'S' || timeOfUse == 's') {
                    bill = customer.consumption * 606.6;
                } else if (timeOfUse == 'O' || timeOfUse == 'o') {
                    bill = customer.consumption * 387.4;
                }
            } else {
                if (timeOfUse == 'P' || timeOfUse == 'p') {
                    bill = customer.consumption * 608.7;
                } else if (timeOfUse == 'S' || timeOfUse == 's') {
                    bill = customer.consumption * 453.8;
                } else if (timeOfUse == 'O' || timeOfUse == 'o') {
                    bill = customer.consumption * 264.6;
                }
            }
            break;
        }
        default:
            cout << "Invalid input" << endl;
            return 0.0;
    }
    return bill;
}

// VAT calculation
float calculateVAT(float bill) {
    return bill * VAT_RATE;
}

// Service fee calculation
float calculateServiceFee(float bill) {
    return bill * SERVICE_FEE_RATE;
}

// Function to output the bill details
void outputBill(const Customer& customer) {
    float vat = calculateVAT(customer.total_bill);
    float serviceFee = calculateServiceFee(customer.total_bill);
    float total = customer.total_bill + vat + serviceFee;

    cout << "\nBill for " << customer.name << endl;
    cout << "Customer Type: ";
    if (customer.customerType == DOMESTIC) cout << "Domestic";
    else if (customer.customerType == COMMERCIAL) cout << "Commercial";
    else if (customer.customerType == MEDIUM_INDUSTRIAL) cout << "Medium Industrial";
    cout << "\nConsumption: " << customer.consumption << " kWh" << endl;
    cout << "Total Bill (without VAT and Service Fee): UGX " << customer.total_bill << endl;
    cout << "VAT (15%): UGX " << vat << endl;
    cout << "Service Fee (5%): UGX " << serviceFee << endl;
    cout << "Total Bill (with VAT and Service Fee): UGX " << total << endl;
    cout << "\n-------------------- THANKS FOR USING ----------------------" << endl;
    cout << "---------------------- C & C Electricity services --------------------" << endl;
}

int main() {
    Customer customer;
    cout << "Enter customer name: ";
    getline(cin, customer.name);
    string customerTypeStr;
    cout << "Enter customer type [Domestic (D), Commercial (C), Medium Industrial (M)]: ";
    cin >> customerTypeStr;
    customer.customerType = determineCustomerType(customerTypeStr);
    if (customer.customerType == UNKNOWN) {
        cout << "Invalid customer type." << endl;
        return 1; // Exit program due to error
    }
    cout << "Enter electricity consumption (in kWh): ";
    cin >> customer.consumption;
    customer.total_bill = calculate_bill(customer);
    if (customer.total_bill <= 0) {
        cout << "Error calculating the bill." << endl;
        return 1;
    }
    outputBill(customer);

    // Writing to file
    ofstream output_file("customer_bill.txt");
    if (output_file.is_open()) {
        float vat = calculateVAT(customer.total_bill);
        float serviceFee = calculateServiceFee(customer.total_bill);
        float total = customer.total_bill + vat + serviceFee;

        output_file << "Bill for " << customer.name << endl;
        output_file << "Customer Type: " << customerTypeStr << endl;
        output_file << "Consumption: " << customer.consumption << " kWh" << endl;
        output_file << "Total Bill (without VAT and Service Fee): UGX " << customer.total_bill << endl;
        output_file << "VAT (15%): UGX " << vat << endl;
        output_file << "Service Fee (5%): UGX " << serviceFee << endl;
        output_file << "Total Bill (with VAT and Service Fee): UGX " << total << endl;
        output_file.close();
        cout << "\n\tAll bill details written to customer_bill.txt" << endl;
    } else {
        cout << "Error opening the file" << endl;
    }
    return 0;
}
